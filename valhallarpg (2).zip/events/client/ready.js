module.exports = (Discord, client) => {
  console.log(`Gem's RPG IS UP!`);
}