const { EmbedBuilder } = require('discord.js');
const players = require('../data/players.json');

module.exports = {
  name: 'char',
  description: 'Display character parameters.',

  async execute(client, message, args) {
    let player = players[message.author.id];

    // Convert gems to gold based on the ratio (1 gem = 0.5 gold)
    const goldAmount = player.balance.coins + player.balance.gems * 0.5;

    const charEmbed = new EmbedBuilder()
      .setColor(0x992e22)
      .setAuthor({ name: `${player.name}` })
      .setDescription(
        `:athletic_shoe: **${player.stats.speed} Speed** \u200b \u200b \u200b :ok_man: **${player.stats.dexterity} Dexterity** \u200b \u200b \u200b :dash: **${player.stats.dodgePercent}% Dodge**\n:shield: **${player.stats.defense} Defense** \u200b \u200b \u200b :crossed_swords: **${player.stats.attack} Attack**\n:brain: **${player.stats.intelligence} Intelligence** \u200b \u200b \u200b :dna: **${player.stats.training} Training**\n:heartbeat: **${player.stats.health} Health** \u200b \u200b \u200b :blue_heart: **${player.stats.mana} Mana**\n:fire: **${player.stats.fireResistance}% Fire Resistance**\n\n:coin: **${goldAmount} Gold** \u200b \u200b \u200b :gem: **${player.balance.gems} Gems**\n\n:round_pushpin: **${player.location}**`
      );
    message.channel.send({ embeds: [charEmbed] });
  },
};
