module.exports = {
	name: 'map',
	description: 'Display a list of available locations',

	async execute(client, message, args) {
		const mapEmbed = {
			color: 0x0099ff,
			description: `:map: **Known locations:**
:evergreen_tree: Forest
:bat: Caves`,
		}

		message.channel.send({ embeds: [mapEmbed] })
	},
}
