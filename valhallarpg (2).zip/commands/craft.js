const { EmbedBuilder } = require('discord.js');
const fs = require('fs');
const players = require('../data/players.json');
const recipes = require('../data/recipes');

module.exports = {
  name: 'craft',
  description: 'Craft items.',

  execute(client, message, args) {
    const playerId = message.author.id;
    const player = players[playerId];
    let backpack = player.inventory.backpack;

    let correctIndex = [];
    for (let i = 0; i < args.length; i++) {
      correctIndex.push(parseInt(args[i] - 1, 10));
    }

    const recipesEmbed = new EmbedBuilder()
      .setColor(0x992e22)
      .setDescription(
        `:tools: **Known crafting recipes:**\n*(To craft an item, required ingredients must be in the backpack)*\n\n${recipes[0]}\n${recipes[1]}`
      );

    message.channel.send({ embeds: [recipesEmbed] });
  },
};
