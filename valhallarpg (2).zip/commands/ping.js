module.exports = {
	name: 'ping',
	description: 'Test command',

	async execute(client, message, args) {
		message.reply('pong')
	},
}
