// newShopItemEffects.js

const applyItemEffect = (player, target, item) => {
  switch (item.name) {
    case 'Sword':
      player.damage += 10;
      break;
    case 'Shield':
      player.defense += 5;
      break;
    case 'Health Potion':
      player.health += 20;
      break;
    case 'Armor':
      player.defense += 15;
      break;
    case 'Magic Staff':
      player.magic += 10;
      break;
    case 'Mana Potion':
      player.mana += 20;
      break;
    case 'Bow':
      player.damage += 8;
      break;
    case 'Arrow Pack':
      player.arrows += 15;
      break;
    case 'Helmet':
      player.defense += 8;
      break;
    case 'Ring of Strength':
      player.strength += 5;
      break;
    case 'Scroll of Healing':
      player.health += 30;
      break;
    case 'Amulet of Wisdom':
      player.intelligence += 5;
      break;
    case 'Dagger':
      player.damage += 5;
      break;
    case 'Gloves of Agility':
      player.speed += 5;
      player.dodge += 5;
      break;
    case 'Scroll of Fireball':
      target.health -= 10;
      target.burning = 2;
      break;
    case 'Boots of Speed':
      player.movementRange += 1;
      break;
    case 'Wand of Ice':
      target.stunned = true;
      player.damage += 5;
      break;
    case 'Book of Knowledge':
      player.intelligence += 5;
      break;
    case 'Elixir of Invisibility':
      player.invisible = true;
      break;
    case 'Cloak of Shadows':
      player.invisible = true;
      break;
    default:
      console.log(`Item effect not defined for ${item.name}`);
  }
};

module.exports = {
  applyItemEffect,
};
