const { MessageEmbed } = require('discord.js');
const fs = require('fs');
const players = require('../data/players.json');

module.exports = {
  name: 'use',
  description: 'Use an item.',

  async execute(client, message, args) {
    const active = players[message.author.id].inventory.active;
    const backpack = players[message.author.id].inventory.backpack;

    const index = args.map(arg => parseInt(arg) - 1).filter(i => !isNaN(i));

    function useItems() {
      if (index.length === 0) {
        const useErrorEmbed = new MessageEmbed()
          .setColor(0x992e22)
          .setDescription('Please provide a valid backpack slot number.');
        return message.channel.send({ embeds: [useErrorEmbed] });
      }

      for (let i = index.length - 1; i >= 0; i--) {
        const itemIndex = index[i];

        if (backpack[itemIndex]) {
          active.push(backpack[itemIndex]);
          backpack.splice(itemIndex, 1);
        } else {
          const useErrorEmbed = new MessageEmbed()
            .setColor(0x992e22)
            .setDescription('Attempted to use an empty backpack slot.');
          return message.channel.send({ embeds: [useErrorEmbed] });
        }
      }

      fs.writeFile('./data/players.json', JSON.stringify(players), err => {
        if (err) console.log(err);
      });

      const useEmbed = new MessageEmbed()
        .setColor(0x992e22)
        .setDescription(`Moved items to active slots: ${index.length}`);
      message.channel.send({ embeds: [useEmbed] });
    }

    if (args.length) {
      useItems();
    } else {
      const useErrorEmbed = new MessageEmbed()
        .setColor(0x992e22)
        .setDescription('Please provide a valid backpack slot number.');
      message.channel.send({ embeds: [useErrorEmbed] });
    }
  },
};
