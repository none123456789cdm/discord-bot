const locations = ["Forest", "Cave", "Castle", "Mountain", "Lake"];
const enemies = ["Goblin", "Skeleton", "Dragon", "Witch", "Troll"];

function adventure_command() {
    const location = locations[Math.floor(Math.random() * locations.length)];
    const enemy = enemies[Math.floor(Math.random() * enemies.length)];

    console.log("You are in the " + location);
    console.log("A wild " + enemy + " appears!");
}

// Call the function to trigger the adventure command
adventure_command();