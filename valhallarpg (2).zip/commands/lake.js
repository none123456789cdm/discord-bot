const { EmbedBuilder } = require('discord.js')
const fs = require('fs')
const players = require('../data/players.json')
const locations = require('../data/locations')

module.exports = {
	name: 'lake',
	description: 'Go to the lake',

	async execute(client, message, args) {
		let player = players[message.author.id]

		if (player.location !== locations[1]) {
			player.location = locations[1]
			fs.writeFile('./data/players.json', JSON.stringify(players), err => {
				if (err) console.log(err)
			})
			const lakeEmbed = new EmbedBuilder()
				.setColor(0x992e22)
				.setDescription(':hook: Here is the Great Lake near the Citadel.')
			message.channel.send({ embeds: [lakeEmbed] })
		} else{
            const lakeErrorEmbed = new EmbedBuilder()
                .setColor(0x992e22)
                .setDescription('You are already at the lake.')
            message.channel.send({ embeds: [lakeErrorEmbed] })
        }
	},
}
