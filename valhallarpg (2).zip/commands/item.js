// items.js

const items = [
  { name: 'Sword', type: 'Weapon', attack: 10 },
  { name: 'Shield', type: 'Defense', attack: 5 },
  { name: 'Health Potion', type: 'Consumable', attack: 0 },
  { name: 'Armor', type: 'Defense', attack: 8 },
  { name: 'Magic Staff', type: 'Weapon', attack: 15 },
  { name: 'Mana Potion', type: 'Consumable', attack: 0 },
  { name: 'Bow', type: 'Weapon', attack: 12 },
  { name: 'Arrow Pack', type: 'Ammunition', attack: 0 },
  { name: 'Helmet', type: 'Defense', attack: 6 },
  { name: 'Ring of Strength', type: 'Accessory', attack: 20 },
  { name: 'Scroll of Healing', type: 'Magic', attack: 0 },
  { name: 'Amulet of Wisdom', type: 'Accessory', attack: 18 },
  { name: 'Dagger', type: 'Weapon', attack: 7 },
  { name: 'Gloves of Agility', type: 'Accessory', attack: 12 },
  { name: 'Scroll of Fireball', type: 'Magic', attack: 10 },
  { name: 'Boots of Speed', type: 'Accessory', attack: 9 },
  { name: 'Wand of Ice', type: 'Magic', attack: 8 },
  { name: 'Book of Knowledge', type: 'Accessory', attack: 14 },
  { name: 'Elixir of Invisibility', type: 'Consumable', attack: 0 },
  { name: 'Cloak of Shadows', type: 'Accessory', attack: 16 },
  // Add more items as needed
];

module.exports = items;
