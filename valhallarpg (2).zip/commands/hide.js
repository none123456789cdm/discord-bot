const { MessageEmbed } = require('discord.js');
const fs = require('fs');
const players = require('../data/players.json');

module.exports = {
  name: 'hide',
  description: 'Hide an item.',

  execute(client, message, args) {
    const active = players[message.author.id].inventory.active;
    const backpack = players[message.author.id].inventory.backpack;

    const index = args.map(arg => parseInt(arg) - 1).filter(i => !isNaN(i));

    function hideItems() {
      if (index.length === 0) {
        const hideErrorEmbed = new MessageEmbed()
          .setColor(0x992e22)
          .setDescription('Please provide a valid active slot number.');
        return message.channel.send({ embeds: [hideErrorEmbed] });
      }

      for (let i = index.length - 1; i >= 0; i--) {
        const itemIndex = index[i];

        if (active[itemIndex]) {
          backpack.push(active[itemIndex]);
          active.splice(itemIndex, 1);
        } else {
          const hideErrorEmbed = new MessageEmbed()
            .setColor(0x992e22)
            .setDescription(`Attempted to hide an empty active slot.`);
          return message.channel.send({ embeds: [hideErrorEmbed] });
        }
      }

      fs.writeFile('./data/players.json', JSON.stringify(players), err => {
        if (err) console.log(err);
      });

      const hideEmbed = new MessageEmbed()
        .setColor(0x992e22)
        .setDescription(`Moved items to backpack: ${index.length}`);
      message.channel.send({ embeds: [hideEmbed] });
    }

    hideItems();
  },
};
