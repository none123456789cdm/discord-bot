const { MessageEmbed } = require('discord.js');

module.exports = {
    name: 'help',
    description: 'See the list of available commands.',

    async execute(client, message, args) {
        const helpEmbed = new MessageEmbed().setColor(0x0099ff).setDescription(
            `:green_circle: **char** - character parameters
            :green_circle: **eq** - equipment
            :green_circle: **item** *backpack slot* - examine item
            :green_circle: **use** *backpack slots* - activate items
            :green_circle: **hide** *active slots* - hide items
            :green_circle: **sell** *backpack slots* - sell items
            :green_circle: **drop** *backpack slots* - drop items
            :red_circle: **upgrade** *backpack slot* - upgrade item
            :red_circle: **training** - skill training
            :red_circle: **craft** - known crafting recipes
            :red_circle: **craft** *recipe number* - craft item
            :yellow_circle: **map** - list of available locations
            :yellow_circle: **adventure** *location name* - adventure
            :red_circle: **spyglass** - track other adventurers
            :red_circle: **attack** *character name* - attack
            :green_circle: **lake** - go to the lake
            :red_circle: **bait** *bait slot* - cast the fishing rod
            :red_circle: **feq** - fishing basket
            :red_circle: **move** *basket slots* - move to backpack
            :red_circle: **rank** - PvP ranking
            :red_circle: **achiev** *character name* - achievements
            :green_circle: **return** - return to the Citadel`
        )
        message.channel.send({ embeds: [helpEmbed] })
    },
};
