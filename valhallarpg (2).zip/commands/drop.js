const { EmbedBuilder } = require('discord.js');
const fs = require('fs');
const players = require('../data/players.json');

module.exports = {
  name: 'drop',
  description: 'Drop items.',

  execute(client, message, args) {
    const playerId = message.author.id;
    const player = players[playerId];
    let backpack = player.inventory.backpack;

    let correctIndex = args.map((arg) => parseInt(arg - 1, 10));

    function dropItems() {
      for (let i = correctIndex.length - 1; i >= 0; i--) {
        backpack.splice(correctIndex[i], 1);
      }
    }

    if (correctIndex.length > 0) {
      for (let i = 0; i < correctIndex.length; i++) {
        if (backpack[correctIndex[i]]) {
          dropItems();
          fs.writeFile('./data/players.json', JSON.stringify(players), (err) => {
            if (err) console.log(err);
          });

          const dropEmbed = new EmbedBuilder()
            .setColor(0x992e22)
            .setDescription(`Dropped items: ${correctIndex.length}.`);
          return message.channel.send({ embeds: [dropEmbed] });
        } else {
          const dropErrorEmbed = new EmbedBuilder()
            .setColor(0x992e22)
            .setDescription('Invalid slot provided.');
          return message.channel.send({ embeds: [dropErrorEmbed] });
        }
      }
    } else {
      const noItemsEmbed = new EmbedBuilder()
        .setColor(0x992e22)
        .setDescription('No valid slots provided.');
      return message.channel.send({ embeds: [noItemsEmbed] });
    }
  },
};
