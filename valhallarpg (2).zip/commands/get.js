const fs = require('fs');
const players = require('../data/players.json');
const items = require('../data/items');

module.exports = {
  name: 'get',
  description: 'Test command.',

  async execute(client, message, args) {
    const playerId = message.author.id;
    const backpack = players[playerId].inventory.backpack;

    const backpackSizeLimit = 5;

    try {
      if (backpack.length < backpackSizeLimit) {
        const randomItem = items[Math.floor(Math.random() * items.length)];
        backpack.push(randomItem);

        fs.writeFile('./data/players.json', JSON.stringify(players), (err) => {
          if (err) {
            console.error('Error writing to players.json:', err);
            message.channel.send('An error occurred while updating the inventory.');
          } else {
            console.log('Item added to backpack:', randomItem);
            message.channel.send(`Added 1 item: ${formatItemDetails(randomItem)}`);
          }
        });
      } else {
        message.channel.send('Your backpack is full.');
      }
    } catch (error) {
      console.error('Error in get command:', error);
      message.channel.send('An unexpected error occurred.');
    }
  },
};

function formatItemDetails(item) {
  return `${item.name} (${item.type}) - Attack: ${item.attack}`;
}
