const { Client, GatewayIntentBits } = require('discord.js');
const { scheduleJob } = require('node-schedule');
const tz = require('timezone/loaded');

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    // Add other necessary intents as needed
  ],
});

let monsterEventActive = false;

client.on('ready', () => {
  console.log(`Logged in as ${client.user.tag}!`);

  // Schedule the gold rain event every hour (3600000 milliseconds)
  setInterval(() => {
    sendGoldToAllUsers();
  }, 3600000);

  // Schedule the shop discount event every day at 5 pm EST
  scheduleJob('0 17 * * *', () => {
    applyShopDiscount();
  });

  // Schedule the monster event every day from 8 pm to 9 pm EST
  scheduleJob('0 20 * * *', () => {
    startMonsterEvent();
  });
});

// Add other event handlers and commands here

client.login('MTIwNzM2MDAyMDU0NzY0MTM3NQ.Gdl9Pz.D8lMzrQvVB6L-MBPHpCSwEzReoUeM8zBln5nZo');

// Function to simulate sending gold to all users
function sendGoldToAllUsers() {
  const guild = client.guilds.cache.get('your-guild-id');

  if (guild) {
    guild.members.cache.forEach((member) => {
      console.log(`Awarding 100 gold to user ${member.user.tag}`);
    });
  } else {
    console.error('Guild not found!');
  }
}

// Function to simulate applying a shop discount
function applyShopDiscount() {
  console.log('Shop discount event started! Shops are 10% cheaper for 10 minutes.');

  // Add your logic for the shop discount event here
  // For example, set a flag or update shop prices
  setTimeout(() => {
    console.log('Shop discount event ended! Shops are back to normal prices.');
    // Reset shop prices or remove the discount flag
  }, 600000); // 10 minutes in milliseconds
}

// Function to start the monster event
function startMonsterEvent() {
  if (!monsterEventActive) {
    monsterEventActive = true;
    console.log('Monster event started! Monsters are stronger now.');

    // Add your logic for the monster event here
    // For example, increase monster stats or spawn stronger versions

    // Simulate monsters dropping 5X loot during the event
    const guild = client.guilds.cache.get('1165661649781391370');

    if (guild) {
      guild.members.cache.forEach((member) => {
        // Simulate each user getting 5X loot
        console.log(`Player ${member.user.tag} received 5X loot from monsters.`);
      });
    } else {
      console.error('Guild not found!');
    }

    // End the monster event after 1 hour (3600000 milliseconds)
    setTimeout(() => {
      console.log('Monster event ended! Monsters are back to normal.');
      monsterEventActive = false;
      // Reset monster stats or remove the event flag
    }, 3600000);
  }
}
