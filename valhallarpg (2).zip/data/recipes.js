module.exports = [
  {
    name: '1. Branch + Wild Tusk',
    description: 'Combining a branch with a wild tusk results in an extraordinary item!',
  },
  {
    name: '2. Wild Hide',
    description: 'Carefully obtained wild hide. It might come in handy for crafting various items.',
  },
];

