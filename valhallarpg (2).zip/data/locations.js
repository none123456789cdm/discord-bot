module.exports = [
  {
    name: 'Cytadela',
    description: 'Mighty fortress, full of mysteries.',
  },
  {
    name: 'Jezioro',
    description: 'Tranquil lake, perfect for relaxation.',
  },
  {
    name: 'Las',
    description: 'Dense forest, full of adventures and dangers.',
  },
];

