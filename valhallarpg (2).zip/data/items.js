module.exports = [
  {
    name: 'Sword',
    type: ':punch:',
    attack: '10',
    description: 'A basic weapon for melee combat.',
    price: '100',
  },
  {
    name: 'Shield',
    type: '\u200B',
    attack: '\u200B',
    description: 'Provides additional defense in battles.',
    price: '80',
  },
  {
    name: 'Health Potion',
    type: '\u200B',
    attack: '\u200B',
    description: 'Restores health when consumed.',
    price: '50',
  },
  // ... (continue with other items)
];
