{
  "scripts": {
    "start": "node index.js"
  }
}
 npm run
node index.js
npm install discord.js
npm install node-schedule timezone
